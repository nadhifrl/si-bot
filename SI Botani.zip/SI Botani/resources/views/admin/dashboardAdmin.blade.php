@extends('layouts.admin')

@section('content')
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Dashboard</h1>
            <ol class="breadcrumb mb-4">
            </ol>
            <div class="row align-items-center no-gutters mb-4 mb-lg-5">
                <div class="col-xl-5 col-lg-6" style="margin-top: 10px;"><img src="img/Logo-Botani-1.png" width="90% "></div>


            </div>
            <div class="col-xl-8 col-lg-5" style="margin-left: 390px;margin-top:-300px;">
                <div class="featured-text text-center text-lg-left">
                    <h1 style="font-size: 90px;font-family:DFPOP1-W9">SELAMAT DATANG</h1>
                </div>
            </div>

        </div>
</div>
@endsection