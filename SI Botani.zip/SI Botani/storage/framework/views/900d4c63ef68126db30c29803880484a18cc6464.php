<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\new ppl project si-bot\terbaru sprint 4\SI Botani\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>