<?php $__env->startPush('customcss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('developer/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- Default box -->



<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Verifikasi</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Memverifikasi</li>
            </ol>
            <div class="box-header">
            </div>
            <!-- /.box-header -->
            <div class="box-body pad">
                <form action="<?php echo e(route('verifikasi.update',$verifikasi->id)); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Verifikasi</label>
                        <select name="status" class="form-control">
                            <option value='Sukses'>Sukses</option>
                            <option value='Gagal'>Gagal</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('verifikasi.index')); ?>" class="btn btn-danger">Batal</a>
                    </div>

                </form>
            </div>
        </div>
</div>
</div>
</div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('customdatatables'); ?>
<script src="<?php echo e(asset('developer/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
<script>
    $(function() {
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
        //CKEDITOR.replace('editor1')
        //bootstrap WYSIHTML5 - text editor
        $('.textarea').wysihtml5()
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-bot\SI Botani\resources\views/admin/verifikasi/edit.blade.php ENDPATH**/ ?>