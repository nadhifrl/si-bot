<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid">
      <h1 class="mt-4">Sarana</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Menambahkan</li>
      </ol>
      <div class="box-header">
      </div>
      <!-- /.box-header -->
      <div class="box-body pad">
        <form action="<?php echo e(route('sarana.store')); ?>" enctype="multipart/form-data" method="POST">
          <?php echo method_field('POST'); ?>
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label>Judul</label>
            <input type="text" class="form-control <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="judul" placeholder="Judul">
            <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
          <div class="form-group">
            <label>Gambar</label>
            <input type="file" class="form-control <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="gambar">
            <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
          <div class="form-group">
            <label>Informasi Sarana</label>
            <textarea name="body" class="<?php if ($errors->has('body')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('body'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Place some text here" style="width: 100%; height: 200px;  line-height: 18px; border: 1px solid #dddddd;">
            </textarea>
            <?php if ($errors->has('body')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('body'); ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary">Tambah Informasi Sarana</button>
            <a href="<?php echo e(route('sarana.index')); ?>" class="btn btn-danger">Batal</a>
          </div>

        </form>
      </div>
    </div>
</div>
</div>
</div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-bot\SI Botani\resources\views/admin/sarana/create.blade.php ENDPATH**/ ?>