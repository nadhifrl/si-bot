<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Selamat Datang ADMIN</h1>
            <ol class="breadcrumb mb-4">
            </ol>
            <div class="row align-items-center no-gutters mb-4 mb-lg-5">
                <div class="col-xl-4 col-lg-7"><img class="img-fluid mb-3 mb-lg-0" src="coba/assets/img/botani-sukorambi.jpg" alt="" /></div>


            </div>
            <div class="col-xl-7 col-lg-5" style="margin-left: 400px;margin-top:-220px;">
                <div class="featured-text text-center text-lg-left">
                    <h1>Taman Botani Sukorambi</h1>
                    <hr>
                    <h4> Taman rekreasi ini diberi nama Taman Botani Sukorambi dimana merupakan taman wisata alam terdekat dari kota Jember (sekitar 10 menit), dengan konsep Rekreasi sambil Belajar dengan luas sekitar 12 hektar, menyajikan aneka ragam koleksi tanaman, hewan, permainan dan wahana-wahana yang dapat dinikmati oleh pengunjung dari segala umur.</h4>
                </div>
            </div>
            <img src="img/Logo-Botani-1.png" width="20% " style="margin-top:-120px;margin-left:70px">

        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-bot\SI Botani\resources\views/admin/dashboardAdmin.blade.php ENDPATH**/ ?>