<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Sarana</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Detail Info</li>
            </ol>


            <div class="col-xl-6 col-lg-6">
                <div>
                    <h1><?php echo e($sarana->judul); ?></h1>
                    <hr>

                    <img class="img-fluid mb-5 mb-lg-0" src="<?php echo e(asset('uploads/'.$sarana->gambar)); ?>" alt="" />
                    <div class="col-xl-60 col-md-90 mx-auto" style="margin-top: 30px;">
                        <div class="container" style="margin-left: -23px;">
                            <div class="card">
                                <div class="card-body">
                                    <p class="text-black-30 mb-0"><?php echo e($sarana->body); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <a href="<?php echo e(route('sarana.index')); ?>" class="btn btn-info" style="margin-top: 10px">Kembali</a>
                    </div>
                </div>
            </div>
        </div>

</div>
</main>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-bot\SI Botani\resources\views/admin/sarana/detail.blade.php ENDPATH**/ ?>