[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\xampp\htdocs\si-bot\SI Botani\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>