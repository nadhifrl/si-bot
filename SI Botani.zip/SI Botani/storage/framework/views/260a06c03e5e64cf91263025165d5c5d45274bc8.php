<?php $__env->startPush('customcss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('developer/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- Default box -->



<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid">
      <h1 class="mt-4">Jadwal</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Mengedit</li>
      </ol>
      <div class="box-header">
      </div>
      <!-- /.box-header -->
      <div class="box-body pad">
        <form action="<?php echo e(route('jadwal.update',$jadwal->id)); ?>" method="POST">
          <?php echo method_field('PUT'); ?>
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label>Jadwal</label>
            <textarea type="text" class="form-control" name="jadwal" placeholder="Isi Jadwal" required><?php echo $jadwal->jadwal; ?></textarea>
          </div>

          <div class="form-group">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-danger">Batal</a>
          </div>

        </form>
      </div>
    </div>
</div>
</div>
</div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('customdatatables'); ?>
<script src="<?php echo e(asset('developer/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
<script>
  $(function() {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    //CKEDITOR.replace('editor1')
    //bootstrap WYSIHTML5 - text editor
    $('.textarea').wysihtml5()
  })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-bot\SI Botani\resources\views/admin/jadwal/edit.blade.php ENDPATH**/ ?>