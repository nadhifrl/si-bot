<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\xampp\htdocs\new ppl project si-bot\terbaru sprint 4\SI Botani\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>