<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Verifikasi Tiket</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Verifikasi</li>
            </ol>
            <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead class="text-center">
                        <tr>

                            <th>No</th>
                            <th>Gambar</th>
                            <th>Bank</th>
                            <th>Nama Rekening</th>
                            <th>Nomor Rekening</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $verifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(( $loop->iteration)); ?></td>
                            <td><img src="<?php echo e(asset('uploads/'.$item->gambar)); ?>" width="50px" height="50px"></td>
                            <td><?php echo e($item->bank); ?></td>

                            <td><?php echo e(str_limit($item->namarekeningpengirim, 20, '...')); ?></td>
                            <td><?php echo e($item->nomorrekening); ?></td>
                            <?php if(!empty($verifikasi)): ?>
                            <td>
                                <a href="<?php echo e(route('sarana.edit',$item->id)); ?>">
                                    <button type="submit" class="btn btn-success">Detail</button>
                                </a>
                                <a href="<?php echo e(route('verifikasi.edit',$item->id)); ?>" class="btn btn-primary">Verifikasi</a>
                                <!-- <form action="<?php echo e(route('verifikasi.update',$item->id)); ?>" enctype="multipart/form-data" class="d-inline" method="POST">
                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-primary " name="status">Verifikasi</button>
                                </form> -->
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-bot\SI Botani\resources\views/admin/verifikasi/index.blade.php ENDPATH**/ ?>