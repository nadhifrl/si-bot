<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Harga Tiket</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Harga Tiket</li>
            </ol>
            <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th class="text-center">Harga Tiket</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $harga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                Rp. <?php echo e($item->harga); ?>

                            </td>
                            <td>
                                <a href="<?php echo e(route('harga.edit',$item->id)); ?>" class="btn btn-info">Edit</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-bot\SI Botani\resources\views/admin/harga/index.blade.php ENDPATH**/ ?>